from django.shortcuts import render
from django.template import loader
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
import smtplib as sm
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
def members(request):
    template = loader.get_template('main.html')
    return HttpResponse(template.render())
def send_email(request):
    if request.method == 'POST':
        sender_email = request.POST.get('sender_email')
        sender_password = request.POST.get('sender_password')
        recipient_email = request.POST.get('recipient_email')
        subject = request.POST.get('subject')
        message = request.POST.get('message')
        context = {
        'mails':sender_email,
        'pass':sender_password,
        'rmail':recipient_email,
        'sub':subject,
        'mes':message,
              }
        template = loader.get_template('template.html')
        return HttpResponse(template.render(context, request))
    

        # Send the email
    # try:
        
    #     server=sm.SMTP("smtp.gmail.com",587)
    #     server.starttls()
    #     server.login("deepak1236969@gmail.com","qtptrybnttluqtks")
    #     from_="deepak1236969@gmail.com"
        
    #     to_='deepakpathak.dmp83@gmail.com'
    #     message=MIMEMultipart("alternative")
    #     message['subject']="testing mail"
    #     message["from"]="deepak1236969@gmail.com"
    #     html='''
    #     <html>
    #     <head>
    #     </head>
    #     <body>
    #     <h1>code with deepak</h1>
    #     <h2>creating  world with coding and co.</h2>
    #     <p>this is the testing for bulk mail sending</p>
    #     </body>
    #     </html>


    #     '''
    #     part2=MIMEText(html,"html")
    #     message.attach(part2)
    #     server.sendmail(from_,to_,message.as_string())
    #     print("message has been send")
    # except Exception as e:
    #     print("error")

    # # Render the form initially
    # return render(request, '404.html')
