from django.urls import path
from . import views

urlpatterns = [
    
    path('', views.members, name='members'),
    path('sendmail/',views.send_email, name='send_email'),
    
]